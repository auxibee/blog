#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      alinko-pc
#
# Created:     21/01/2017
# Copyright:   (c) alinko-pc 2017
# Licence:     <your licence>
#-------------------------------------------------------------------------------

from app import db
from sqlalchemy import func
from app import app
from datetime import datetime


followers = db.Table('followers',
       db.Column('follower_id',db.Integer,db.ForeignKey('user.id')),
       db.Column('followed_id',db.Integer,db.ForeignKey('user.id'))
       )

class User(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64),index=True, unique=True)
    email    = db.Column(db.String(120),index=True, unique=True)
    password = db.Column(db.String(120),index=True)
    posts = db.relationship('Posts', backref='author',lazy='dynamic')
    comments = db.relationship('Comments', backref='author',lazy='dynamic')
    about_me = db.Column(db.String(140))
    registrated_on = datetime.utcnow()
    last_seen = db.Column(db.DateTime)
    confirmed = db.Column(db.Boolean,default=False)
    confirmation_token = db.Column(db.String(64),nullable=False)
    followed = db.relationship('User',secondary=followers,primaryjoin=(followers.c.follower_id == id),
                                        secondaryjoin=(followers.c.followed_id == id),
                                        backref=db.backref('followers',lazy='dynamic'),
                                        lazy='dynamic')



    def username_exits(self,m_username):
        user = User.query.filter_by(username = m_username).first()
        if user is not None:
            return True
        else:
            return False

    def email_exits(self,m_email):
        user_email = User.query.filter_by(email = m_email).first()
        if user_email is not None:
            return True
        else:
            return False

    def confirm_registion(self,token,email):
        confirm = User.query.filter_by(email = email,confirmation_token = token).first()
        if confirm is not None:
            return True
        else:
            return False


    def follow(self,user):
        if not self.is_following(user):
            self.followed.append(user)
            return self

    def unfollow(self,user):
        if self.is_following(user):
            self.followed.remove(user)
            return self

    def is_following(self,user):
        return self.followed.filter(followers.c.followed_id == user.id).count() > 0

    def followed_post(self):
        return Posts.query.join(followers,(followers.c.followed_id == Posts.user_id)).filter(followers.c_followers_id == self.id).order_by(Posts.timestamp.desc())

    def get_user_count(self):
        return db.session.query(func.count(User.id)).scalar()


    @property
    def is_authenticated(self):
        return True

    @property
    def is_active(self):
        return True

    @property
    def is_anonymous(self):
        return False


    def get_id(self):
        try:
            return unicode(self.id)
        except NameError:
            return str(self.id)


    def __repr__(self):
        return '<User %r>' %(self.username)


class Posts(db.Model):
    __tablename__ = "posts"

    id = db.Column(db.Integer, primary_key=True)
    topic = db.Column(db.String())
    body = db.Column(db.String(140))
    timestamp = db.Column(db.DateTime)
    category = db.Column(db.String(20))
    post_views = db.Column(db.Integer)
    user_id = db.Column(db.Integer,db.ForeignKey('user.id'))



    def all_post(self):
        return Posts.query.join(User)

    def posts_by_userid(self,user_id):
        return  Posts.query.join(User).filter(Posts.user_id == user_id)

    def posts_by_category(self,category):
        return  Posts.query.join(User).filter(Posts.category == category)

    def search_posts(self,search_term):
        return Posts.query.filter(Posts.topic.like( search_term + "%"))

    def get_posts_count(self):
        return db.session.query(func.count(Posts.id)).scalar()

    def get_post_by_id(self,id):
        return  Posts.query.filter(Posts.id == id)


    def __repr__(self): # pragma: no cover
        return '<Post %r>' %(self.body)


class Comments(db.Model):
    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.String(140))
    timestamp = db.Column(db.DateTime)
    post_id  = db.Column(db.Integer,db.ForeignKey('posts.id'))
    user_id = db.Column(db.Integer,db.ForeignKey('user.id'))

    def get_post_comments(self,post_id):
        return  Comments.query.join(User).filter(Comments.post_id == post_id)





