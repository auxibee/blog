#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      alinko-pc
#
# Created:     21/01/2017
# Copyright:   (c) alinko-pc 2017
# Licence:     <your licence>
#-------------------------------------------------------------------------------

from flask import Flask
from flask_mail import Mail
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import basedir, ADMINS, MAIL_USERNAME, MAIL_PASSWORD, MAIL_SERVER, MAIL_PORT
from .momentjs import momentjs

app = Flask(__name__)

if not app.debug:
    import logging
    from logging.handlers import SMTPHandler
    credentials = None
    if MAIL_USERNAME or MAIL_PASSWORD:
        credentials = (MAIL_USERNAME,MAIL_PASSWORD)
        mail_handler = SMTPHandler((MAIL_SERVER,MAIL_PORT),'no-reply@' + MAIL_SERVER, ADMINS,'microblog failure',credentials)
        mail_handler.setLevel(logging.ERROR)
        app.logger.addHandler(mail_handler)

if not app.debug:
    import logging
    from logging.handlers import RotatingFileHandler
    file_handler = RotatingFileHandler('tmp/microblog.log', 'a', 1 * 1024 * 1024, 10)
    file_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'))
    app.logger.setLevel(logging.INFO)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.info('microblog startup')

app.config.from_object('config')

app.jinja_env.globals['momentjs'] = momentjs
db = SQLAlchemy(app)

mail = Mail(app)

login_manager = LoginManager()

login_manager.init_app(app)

from app import views,models
