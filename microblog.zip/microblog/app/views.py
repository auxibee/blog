#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      alinko-pc
#
# Created:     21/01/2017
# Copyright:   (c) alinko-pc 2017
# Licence:     <your licence>
#-------------------------------------------------------------------------------

from app import app, db, login_manager
from flask import render_template,redirect,flash,session,g,url_for,request
from .forms import LoginForm,RegisterForm,EditForm,NewPostForm,SearchForm,CommentForm
from .models import User,Posts,Comments
from flask_login import login_user,logout_user,current_user,login_required
from datetime import datetime
from config import POSTS_PER_PAGE
from config import MAX_SEARCH_RESULTS
from config import CATEGORIES
from config import DATABASE_QUERY_TIMEOUT
from config import ADMINS
from r_token import generate_token,confirm_token
from flask_sqlalchemy import get_debug_queries
from emails import send_email

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.htm'),404


@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.htm'),500

@app.errorhandler(401)
def unauthorized(error):
    return render_template('401.htm'),401

#returns user_id when user exits
def check_if_user_exits(username):
    user = User.query.filter_by(username = username).first()
    if user is None:
        return redirect('/index')
    else:
        user_id = user.id
        return user_id



@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

@app.before_request
def before_request():
    g.categories = CATEGORIES
    g.user = current_user
    g.posts = Posts()
    if g.user.is_authenticated:
        g.user.last_seen = datetime.utcnow()
        db.session.add(g.user)
        db.session.commit()
    g.search_form = SearchForm()
    u = User()
    g.user_count = u.get_user_count()


@app.after_request
def after_request(response):
    for query in get_debug_queries():
        if query.duration >= DATABASE_QUERY_TIMEOUT:
            app.logger.warning("SLOW QUERY: %s\nParameters: %s\nDuration: %fs\nContext: %s\n" % (query.statement, query.parameters, query.duration, query.context))
    return response



@app.route('/')
@app.route('/index')
@app.route('/index/<int:page>')
def index(page=1):
    title = 'Homepage'
    posts_count = g.posts.get_posts_count()
    p = g.posts.all_post().paginate(page,POSTS_PER_PAGE,False)
    return render_template('index.htm',title=title,posts=p,posts_count=posts_count)



@app.route('/login', methods=['GET','POST'])
def login():

    title = 'Sign In'
    form = LoginForm()
    if form.validate_on_submit():
        username    = form.username.data
        password    = form.password.data
        remember_me = form.remember_me.data
        user = User.query.filter_by(username = username,password = password).first()
        if user is None:
            flash("Wrong username or password")
            return redirect('/login')

        login_user(user,remember_me)

        return redirect('/index')
    else:
        return render_template('login.htm',form=form, title=title)



@app.route('/register', methods=['GET','POST'])
def register():
    title = "Join ghtalks"

    form = RegisterForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        email    = form.email.data
        token = generate_token(email)
        new_user = User(username=username, email=email, password=password, confirmation_token=token)

        username_exits = new_user.username_exits(username)
        if username_exits == True:
            flash("Username already exits")
            return redirect('/register')

        email_exits = new_user.email_exits(email)
        if email_exits == True:
            flash("Email already in use")
            return redirect('/register')

        db.session.add(new_user)
        db.session.commit()
        #send_email("Microblog- Confirm registration",ADMINS[0],email,
                #   render_template("registration_confirmation.txt",username=username,token=token),
                 #  render_template("registration_confirmation.htm",username=username,token=token))

        flash("An email has been sent to your email address please confirm your registration")
        return redirect('/login')
    else:
        return render_template('register.htm',form=form, title=title)


@app.route('/confirm/<token>')
def confirm(token):
    try:
        email = confirm_token(token)
    except:
        flash("The confirmation link is invalid or has expired")
        return redirect('/index')
    user = User.query.filter_by(email = email).first()
    if g.user.confirmed:
        flash("Account already confirmed you can login now")
        return redirect('/index')
    else:
        g.user.confirmed = True
        db.session.add(g.user)
        db.session.commit()
        flash("You have confirmed your account .Please login in now")
    return redirect('/index')


@app.route('/logout')
def logout():
    logout_user()
    return redirect('/index')

@app.route('/user/<username>')
@app.route('/user/<username>/<int:page>')
@login_required
def user(username,page=1):

    user = User.query.filter_by(username = username).first()
    if user is None:
        flash("user does not exits")
        return redirect('/index')
    user_id = user.id
    p = g.posts.posts_by_userid(user_id).paginate(page,POSTS_PER_PAGE,False)

    return render_template('user.htm',user_id=user_id, user=user, posts=p)

@app.route('/edit/<username>',methods= ['GET','POST'])
@login_required
def edit(username):
    title = "Edit Profile"


    user_id = check_if_user_exits(username)

    form = EditForm()
    if form.validate_on_submit():
        g.user.about_me = form.about_me.data
        db.session.add(g.user)
        db.session.commit()
        flash("Your changes have been saved...")
        return redirect(url_for('edit',username=username))
    else:
        return render_template('edit.htm',form=form,title=title,user_id=user_id)


@app.route('/new_post/<category>',methods= ['GET','POST'])
@login_required
def new_post(category):
    title = "New Post"
    form = NewPostForm()

    user_id = check_if_user_exits(g.user.username)

    if form.validate_on_submit():
        topic = form.title.data
        body = form.body.data
        category = category
        post_time = datetime.utcnow()
        posted_by = user_id
        post_views = 1

        post = Posts(topic=topic,body=body,timestamp=post_time,category=category,user_id=user_id,post_views=post_views)
        db.session.add(post)
        db.session.commit()
        #flash("Post added succesfully in t/ %s"%(category))
        return redirect(url_for('index'))
    else:
        return render_template('new_post.htm',form=form,title=title,user_id=user_id,category=category)



@app.route('/<title>/<int:post_id>')
@app.route('/<title>/<int:post_id>/<int:page>')
def view_post(title,post_id,page=1):
    m_topic = title.replace("-"," ")
    post = Posts.query.filter_by(topic=m_topic,id=post_id).first()

    if post is None:
        flash('The article you are looking is missing')
        return redirect('/index')

    #increase post views counter
    post.post_views += 1
    db.session.commit()
    comments = Comments()
    #p = g.posts.all_post().paginate(page,POSTS_PER_PAGE,False)
    c = comments.get_post_comments(post_id).paginate(page,POSTS_PER_PAGE,False)

    return render_template('post.htm',title=m_topic,post=post,comments=c)




@app.route('/search',methods=['POST'])
@login_required
def search():
    if not g.search_form.validate_on_submit():
        return redirect('/index')
    else:
        query = g.search_form.search_term.data
        return redirect(url_for('search_results',query=query))



@app.route('/search_results/<query>')
@login_required
def search_results(query):
    title = "Search: " + query
    p = g.posts.search_posts(query)
    m_posts = p.paginate(1,POSTS_PER_PAGE,False)

    return render_template('search_results.htm',query=query,posts=m_posts,title=title)

@app.route('/t/<category>')
@app.route('/t/<category>/<int:page>')
def t(category):
    title = category
    p = g.posts.posts_by_category(category)
    m_posts = p.paginate(1,POSTS_PER_PAGE,False)
    return render_template('category_posts.htm',posts=m_posts,title=title,category=category)

@app.route('/delete/<int:post_id>')
@login_required
def delete(post_id):
    post = Posts.query.get(post_id)
    if post is None:
        flash("Post was not found")
        return redirect(url_for('index'))
    if post.user_id != g.user.id:
        flash("You cannot delete this post")
        return redirect(url_for('index'))
    db.session.delete(post)
    db.session.commit()
    flash("your post has been deleted successfully")
    return redirect(url_for('user',username=g.user.username))

@app.route('/edit/<int:post_id>',methods=['GET','POST'])
@login_required
def edit_post(post_id):
    post = Posts.query.get(post_id)
    if post is None:
        flash("Post was not found")
        return redirect(url_for('index'))
    if post.user_id != g.user.id:
        flash("You cannot delete this post")
        return redirect(url_for('index'))

    form = NewPostForm()
    form.title.data = post.topic
    form.body.data = post.body
    title = "Edit - " + post.topic
    if form.validate_on_submit():
        post.topic = request.form.get('title')
        post.body = request.form.get('body')
        db.session.commit()
        flash("Post edited succesfully")
        return redirect(url_for('user',username=g.user.username))
    else:
        return render_template('edit_post.htm',form=form,title=title,post_id=post_id)


@app.route('/comment/<int:post_id>',methods=['GET','POST'])
@login_required
def comment(post_id):

    post = Posts.query.get(post_id)
    if post is None:
        flash("Post was not found")
        return redirect(url_for('index'))
    form = CommentForm()
    title =  post.topic
    if form.validate_on_submit():

        body = form.body.data
        post_id = post.id
        user_id = g.user.id
        timestamp = datetime.utcnow()
        comment = Comments(body=body,post_id=post_id,user_id=user_id,timestamp=timestamp)
        db.session.add(comment)
        db.session.commit()
        return redirect(url_for('comment',post_id=post.id))
    return render_template('comment.htm',form=form,title=title,post=post)

