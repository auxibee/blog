#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      alinko-pc
#
# Created:     21/01/2017
# Copyright:   (c) alinko-pc 2017
# Licence:     <your licence>
#-------------------------------------------------------------------------------

from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField,PasswordField,TextAreaField
from wtforms.validators import DataRequired,Email,Length,Regexp
from app.models import User

class LoginForm(FlaskForm):
    username = StringField('username',validators=[DataRequired()])
    password = PasswordField('password',validators=[DataRequired()])
    remember_me = BooleanField('remember_me',default=False)


class RegisterForm(FlaskForm):
    username = StringField('username',validators=[DataRequired(),Length(min=4,max=15),Regexp(r'^[\w.@+-]+$')])
    email = StringField('email',validators=[DataRequired(),Email("wrong email address")])
    password = PasswordField('password',validators=[DataRequired()])


class EditForm(FlaskForm):
    about_me = TextAreaField('about_me',validators=[Length(min=0,max=140)])


class NewPostForm(FlaskForm):
    title = StringField('title',validators=[DataRequired()])
    body = TextAreaField('body',validators=[Length(min=0,max=10000)])

class SearchForm(FlaskForm):
    search_term = StringField('search',validators=[DataRequired()])

class CommentForm(FlaskForm):
    body = TextAreaField('body',validators=[Length(min=0,max=1000)])



